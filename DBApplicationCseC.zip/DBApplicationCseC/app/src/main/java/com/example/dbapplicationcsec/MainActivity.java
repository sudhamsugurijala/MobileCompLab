package com.example.dbapplicationcsec;

import androidx.appcompat.app.AppCompatActivity;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "gds";
    database db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button bt_insert=findViewById(R.id.bt_insert);
        Button bt_update=findViewById(R.id.bt_update);
        Button bt_delete=findViewById(R.id.bt_delete);
        Button bt_display=findViewById(R.id.bt_display);

        final EditText et_code=findViewById(R.id.et_code);
        final EditText et_name=findViewById(R.id.et_name);
        final EditText res_text=findViewById(R.id.res_text);

        db=new database(getApplicationContext());

        bt_insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                db.insert(Integer.parseInt(et_code.getEditableText().toString()),et_name.getEditableText().toString());
                String output = "Insert Success";
                res_text.setText(output);
            }
        }
        );

        bt_update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                db.update(Integer.parseInt(et_code.getEditableText().toString()),et_name.getEditableText().toString());
                String output = "Update Success";
                res_text.setText(output);
            }
        }
        );

        bt_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int flag = db.delete(Integer.parseInt(et_code.getEditableText().toString()));
                if(flag>0) {
                    String output = "Deleted "+flag+" records";
                    res_text.setText(output);
                }
                else {
                    String output = "No records found to delete";
                    res_text.setText(output);
                }
            }
        }
        );

        bt_display.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor res=db.display(Integer.parseInt(et_code.getEditableText().toString()));
                if (res.moveToNext() == false) {
                    String output = "No Records Found";
                    res_text.setText(output);
                }
                while(res.moveToNext()){
                    Log.d(TAG,Integer.toString(res.getInt(0)) + "---" + res.getString(1));
                    String output = Integer.toString(res.getInt(0)) + "---" + res.getString(1);
                    res_text.setText(output);
                }
            }
        }
        );
    }
}

