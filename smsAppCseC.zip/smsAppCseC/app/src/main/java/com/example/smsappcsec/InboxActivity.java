package com.example.smsappcsec;

import androidx.appcompat.app.AppCompatActivity;
import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.widget.TextView;
public class InboxActivity extends AppCompatActivity {
    public static boolean active = false;
    public static InboxActivity inst;
    TextView msgs;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        inst = this;
        refreshInbox();
    }
    void refreshInbox() {
        InboxActivity.this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                setContentView(R.layout.activity_inbox);
                msgs = findViewById(R.id.msgs);
                String m = "";
                ContentResolver c = getContentResolver();
                Cursor i = c.query(Uri.parse("content://sms/inbox"), null, null, null, null);
                if(!i.moveToFirst()) {
                    return;
                }
                else {
                    do {
                        m = m + "From: " + i.getString(i.getColumnIndex("address")) + "\nMessage: " +
                                i.getString(i.getColumnIndex("body")) + "\n\n";
                    } while(i.moveToNext());
                    msgs.setText(m);
                }
            }
        });
    }
    public static InboxActivity instance() {
        return inst;
    }
    @Override
    protected void onStart() {
        super.onStart();
        active = true;
        inst = this;
    }
    @Override
    protected void onStop() {
        super.onStop();
        active = false;
        inst = null;
    }
}