package com.example.alarmappcsec;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.RequiresApi;

import java.util.Calendar;


public class AlarmReceiver extends Activity
{
    Uri alarmUri;
    Ringtone ringtone;
    PendingIntent pendingIntent;
    AlarmManager alarmManager;

    public void onCreate (Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button on = findViewById(R.id.bt_on);
        Button off = findViewById(R.id.bt_off);
        Button snooze = findViewById(R.id.bt_snooze);
        on.setVisibility(View.GONE);
        Toast.makeText(this, "Alarm! Have A Good Day", Toast.LENGTH_LONG).show();
        alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        if (alarmUri == null) {
            alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        }
        ringtone = RingtoneManager.getRingtone(this, alarmUri);
        ringtone.play();

        off.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ringtone.stop();
                Toast.makeText(AlarmReceiver.this,"ALARM TURNED OFF", Toast.LENGTH_LONG).show();
                Intent i = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(i);
            }
        });

        snooze.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.KITKAT)
            @Override
            public void onClick(View v) {
                Toast.makeText(AlarmReceiver.this, "SNOOZE 1 MINUTE", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(getApplicationContext(), AlarmReceiver.class);
                pendingIntent = PendingIntent.getActivity(getApplicationContext(), 0, intent, 0);
                // 60000 modulo to strip all the milliseconds
                long time = System.currentTimeMillis();
                time += (1000*60);
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, time, pendingIntent);
            }
        });
    }

}